# Sanity Checks

## Usage
These sketches are provided for a sanity check of your transmitter and receiver units.  Ideally you would use one Arduino for the transmitter and one Arduino for the receiver.

### Sender
The purpose of this sketch is to pulse the pin you have attached your transmitter's data pin to.

### Receiver
The purpose of this sketch is to light pin 13's LED in accordance with the signal received on  the receiver's data pin.



