﻿!!!! ACHTUNG !!!!
www-data braucht rechte für /dev/mem und /dev/gpiomem (ich habe chmod 777 vergeben, die Seite nur im LAN verfügbar ist.)